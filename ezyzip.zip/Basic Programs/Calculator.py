def add(x ,y):
    return x+y
def sub(x,y):
    return x-y
def mul(x,y):
    return x*y
def div(x, y):
    return x/y

print("Select operation")
print("1.Add")
print("2.Subtract")
print("3.Multiply")
print("4.Division")

while True:
    choice=input("enter the choice")
    if choice in ('1','2','3','4'):
        n1=int(input("First number:"))
        n2 = int(input("second number:"))
        if choice=='1':
            print(add(n1,n2))
        elif choice=='2':
            print(sub(n1,n2))
        elif choice=='3':
            print(mul(n1,n2))
        elif choice=='4':
            print(div(n1,n2))
            next_calculation=input("next")
            if next_calculation=="no":
                break
        else:
            print("invalid")


