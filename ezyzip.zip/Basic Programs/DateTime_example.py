import calendar
import time
import pytz
from datetime import datetime
# print(time.time())
# print(time.asctime(time.locatime(time.time())))
# pytz.timezone('America')
# aware_us_central = datetime.now(pytz.timezone('US/Central'))
# print('US Central DateTime', aware_us_central)
time1= pytz.timezone('America/Adak')
print("Current time :",datetime.now(time1))
