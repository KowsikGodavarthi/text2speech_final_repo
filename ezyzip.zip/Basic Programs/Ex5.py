from Example4 import a3

class a4(a3):
    def a5(self):
        print("I am good")


obj=a4()
obj.a4()