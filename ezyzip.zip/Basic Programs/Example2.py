class KLU:
    print('hello')
    def a1(self):
        print('Good Morning')
    def a2(self):
        #a3=a5+a6
        #print(a9)
        print(self.a7+self.a8)
    def __init__(self,a7,a8):
        self.a7=a7
        self.a8=a8
        #a9=a7+a8
cse = KLU(2,3)
cse.__init__(4,5)
cse.a1()
cse.a2()
#cse.a2(2,3)