class s1:
    def s2(self):
        print('cse1')
class s2(s1):
    def s3(self):
        print('cse2')
obj=s2()
obj.s2()
obj.s3()