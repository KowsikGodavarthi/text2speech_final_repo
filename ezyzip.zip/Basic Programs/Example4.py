class a1:
    def a2(self):
        print("Hello")

class a3(a1):
            def a4(self):
                print("How r u")