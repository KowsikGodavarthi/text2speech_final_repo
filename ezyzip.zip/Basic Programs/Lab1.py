class accountb():
    accountbalence1=10000
    accountname="SREEKAR-PERSONAL"
    bankname="BANK"
class customer(accountb):
    customername="SREEKAR"
    phonenumber=9347266346
class deposit(customer):
    pass
class withdraw(deposit):
    pass
class display(withdraw):
    pass

while True:

    print("SELECT THE CHICE")
    choice = input("1.ACCOUNT DETAILS \n2.CUSTOMER DETAILS \n3.WITHDRAW \n4.DEPOSIT \n5.EXIT\n")
    if choice in ('1', '2', '3', '4', '5'):
        c = display
        if choice == '1':
            print(c.accountbalence1, c.bankname, c.accountname)
        elif choice == '2':
            print(c.customername, c.phonenumber)
        elif choice == '3':
            amt = int(input("enter the amount to withdraw"))
            if amt > c.accountbalence1:
                print("LESS BALENCE")
            else:
                c.accountbalence1 = c.accountbalence1 - amt
                print(c.accountbalence1)
        elif choice == '4':
            amt = int(input("enter the amount to deposit"))
            c.accountbalence1 = c.accountbalence1 + amt
            print(c.accountbalence1)
        elif choice == '5':
            break
        next_calculation = input("do you wanna continue!(YES/NO):")
        if next_calculation == 'NO':
            break
        elif next_calculation == 'YES':
            print("OK GOING FOR NEXT ROUND")
        else:
            print("WRONG INPUT")