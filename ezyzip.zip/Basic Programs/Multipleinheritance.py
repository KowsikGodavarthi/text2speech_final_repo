class A:
    def __init__(self):
        print("intialise with A")
    def sub_method(self,a):
        print("Printing class A",a)
class B():
    def __init__(self):
        print("Intiaise with B")
        super().__init__()
        def sub_method(self,a):
            print("printing class B",a)
            super().sub_method(a+1)
class C(A,B):
    def __init__(self):
        print("Intiaise with C")
        super().__init__()
        def sub_method(self,a):
            print("printing class c",a)
            super().sub_method(a+1)

obj=C()
obj.sub_method(1)