import os
print(os.name)
# os.mkdir("d:\\olddir")
# print(os.getcwd())

path='./os.txt'
flags=os.O_RDWR |os.O_CREAT
g= os.open(path, flags)
str = "Hello"
os.write(g, str.encode())
os.lseek(g, 0 , 0)
str1= os.read(g, os.path.getsize(g))
print(str1)
print(str1.decode())