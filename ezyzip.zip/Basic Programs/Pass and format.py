for numb in range(1,5):
    if numb==2:
        pass
    else:
        print("Present num=[]".format(numb))