# import re
# str="Virat Kohli is an Indian international cricketer and " \
#     "former captain of the India national cricket team. " \
#     "He is widely regarded as one of the greatest batsman of all time. " \
#     "Kohli plays as a right-handed batsman for Royal Challengers Bangalore in the Indian Premier League" \
#     " and for Delhi in domestic Indian cricket."
# mw=re.findall("is",str)
# print(mw)
# sd=re.search("He",str)
# print(sd)
# jh=re.match("Virat",str)
# print(jh)
# kj=re.split("as",str)
# print(kj)
# s=re.fullmatch("the",str,0)
# print(s)
