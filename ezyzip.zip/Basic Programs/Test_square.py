import math
def test_sqrt():
    num=25
    assert math.sqrt(num) == 5

def testsquare():
    num1=7
    assert 7*7 == 40

def testequality():
    assert 10 == 11


