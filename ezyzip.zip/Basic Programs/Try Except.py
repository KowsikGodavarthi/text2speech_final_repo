try:
    a=int(input("Enter a :"))
    b=int(input("Enter b :"))
    c=a/b
    print("a/b=%d",c)
except Exception as e:
    print("cant divide by zero")
    print(e)
else:
    print("values which divided")
    print(c)