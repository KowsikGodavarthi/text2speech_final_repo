try:
    rty=int(input())
    for xs in range(rty):
        sd,df,fg = map(int,input().split())
        for de in range(2,100):
            if(sd%de!=0):
                if(df%de!=0):
                    if(fg%de!=0):
                        break
        print(de)
except:
    pass