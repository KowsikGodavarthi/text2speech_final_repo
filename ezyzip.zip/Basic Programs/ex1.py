# print("Sreekar")
# a1=10
# a2='KLU'
# a3=23.423
# a4=5+3j
# a5=True
# a6=float(input("enter the data"))
# print(a3+a4)
# a7={2100:"sreekar",30464:"mani babu",30001:"afroz"}
# print(a7.values())
# a8={1,5,2,3,4,(23.45,'sreekar')}
# print(type(a8))
# a9=(1,35,5,{2100:'mani',2540:'sai'})
# print(type(a9))
# a10=[1,5,2,4,{1,8,2}]
# print(type(a10))
#
# marks={'sai':4,'saz':5}
# print(type(marks))
# for i in marks:
#     print(i,"",marks[i])
# c=0
# while c<5:
#     print(c,'the count is less than ')
#     c=c+1
# else:
#     print(c,'is no less than 5')
