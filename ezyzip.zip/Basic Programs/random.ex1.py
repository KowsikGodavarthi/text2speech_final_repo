import random
n=random.randbytes(3)
print(n)
a1=[5,6,7]
a2=(1,2,3)
a3 ={8,9,"sreekar"}
a4={1:"Sreekar",2:"mani Babu",3:"Afrooz"}
# print(random.choices(a4))
# print(random.shuffle(a2)) 
print(random.getrandbits(3))
print(random.randint(1,10000))
print(random.randrange(1,2000000000,1))
print(random.random())
print(random.triangular(30.8,31.5,36.7))

