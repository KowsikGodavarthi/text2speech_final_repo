from flask import *

app = Flask(__name__)
#
# @app.route('/table/<int:num>')
# def table(num):
#     return render_template('table.html', n=num)

@app.route('/', methods=['POST'])
def table1():
    num = request.form.get('num', type=int, default=0)
    if num>0:
        return render_template('table.html', n=num)
    else:
        return "ERROR"
if __name__ == '__main__':
    app.run(debug=True)