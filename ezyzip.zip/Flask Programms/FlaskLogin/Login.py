# # from flask import *
# # app=Flask(__name__)
# # @app.route('/')
# # def home():
# #     return render_template('base.html')
# # @app.route('/s',methods=['POST'])
# # def login():
# #     uname=request.form['uname']
# #     password=request.form['pass']
# #     if uname == "Sreekar" and password=="12345":
# #         return "<h1><center><font color='blue'><br><br><br><b><i>welcome%s</i></b></center></h1>"
# #     else:
# #         return"<h1><center><font color='red'><br><br><br><b>wrong username</b></center></h1>"
# # if __name__ =='__main__':
# #     app.run()
from flask import *
from pymongo import MongoClient

app=Flask(__name__)
@app.route('/')
def home():
    return render_template('base.html')
@app.route("/loginuser",methods=['POST','GET'])
def login():
    return render_template('login.html')
    # ename = request.form.get("username")
    # epass = request.form.get("password")
    # cpass = request.form.get("cpassword")
    # # Connect to MongoDB
    # client = MongoClient('mongodb://locolhost:27017/')
    # db = client["sdp"]
    # collection = db["sdp"]
    # user = {"username":ename, "password": epass, "confirm-password": cpass}
    # result = collection.insert_one(user)
    # if result != None:
    #     return "<h1><center>HOLA!! U CREATED U ACCOUNT PLEASE LOGIN</center></h1>"
    # else:
    #     return "<h1><center>invalid</center></h1>"

@app.route("/registeruser", methods=['POST','GET'])
def my_regiser_user():
    return render_template('newuserregister.html')
    # entered_username = request.form.get("username")
    # entered_password = request.form.get("password")
    # entered_password = entered_password.lower()
    # entered_email = request.form.get("email")
    # entered_mobileno = request.form.get("mobileno")
    #
    # client = MongoClient('mongodb://localhost:27017/')
    # db = client['Employee']
    # info = db.Employee
    # register = db.Registered
    # user = {"Username":entered_username, "Password":entered_password, "email":entered_email, "Mobile_number":entered_mobileno}
    # result = register.insert_one(user)
    # print(entered_username, entered_password, entered_email, entered_mobileno)

@app.route("/index", methods=['POST','GET'])
def index():
    return render_template('index.html')
if __name__ =='__main__':
    app.run()

