from flask import Flask,render_template

app = Flask(__name__)


@app.route('/')
def hello():
    return 'Hello, World!'
@app.route("/s17")
def function2():
    return "<font color = 'blue'><center><br><br><br><br><b><h1>My name is Sreekar"
#
# @app.route('/page/<float:id>')
# def fun(id):
#     return 'the Entered Register num %d' %id

@app.route('/page1')
def fun2():
    return render_template("hello.html")

@app.route('/s2')
def fun3():
    return render_template("hello1.html")

@app.route('/s3')
def fun4():
    return render_template("Button.html")
if __name__ == "__main__":
    app.run()