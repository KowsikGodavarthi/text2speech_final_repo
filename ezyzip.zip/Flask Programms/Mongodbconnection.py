import pymongo

from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
db = client.test
student1= {"Reg Num":"210030708","Name":"Sreeka"}

student2 = [
       {"Reg Num":"210030700","Name":"Sreekar"},
       {"Reg Num":"210030701","Name":"Sreer"},
       {"Reg Num":"210030702","Name":"Sreesai"}
     ]
db= client['PFSD']

studentdata=db.student123
studentdata.insert_one(student1)
studentdata.insert_many(student2)
studentdata.delete_one(student1)
print("Completed")