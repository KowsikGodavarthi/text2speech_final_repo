import math
class AreaPeri:
    def rectangle_peri(self, len, bre):
        return 2 * (len + bre)

    def rectangle_area(self, len, bre):
        return len * bre

    def triangle_peri(self, s1, s2, s3):
        return s1 + s2 + s3

    def triangle_area(self, s1, s2, s3):
        S = (s1 + s2 + s3) / 2
        return math.sqrt(S * (S - s1) * (S - s2) * (S - s3))

    def circle_cir(self, radius):
        return 2 * 3.14 * radius

    def circle_area(self, radius):
        return 3.14 * radius * radius


choice = input().split(' ')
shape = AreaPeri()
no_sides = len(choice)
if no_sides == 3:
    print("Triangle\n")
    print("Area : ", shape.triangle_area(int(choice[0]), int(choice[1]), int(choice[2])))
    print("Perimeter: ", shape.triangle_peri(int(choice[0]), int(choice[1]), int(choice[2])))

elif no_sides == 2:
    print("Rectangle\n")
    print("Area : ", shape.rectangle_area(int(choice[0]), int(choice[1])))
    print("Perimeter: ", shape.rectangle_peri(int(choice[0]), int(choice[1])))

elif no_sides == 1:
    print("Circle\n")
    print("Area : ", shape.circle_area(int(choice[0])))
    print("Circumference: ", shape.circle_cir(int(choice[0])))

else:
    print("Invalid Input")