class BankAccount:
    # create the constuctor with parameters: accountNumber, name and balance
    def init(self, accountNumber, name, balance):
        self.accountNumber = accountNumber
        self.name = name
        self.balance = balance

        # create Deposit() method

    def Deposit(self, d):
        self.balance = self.balance + d

        # create Withdrawal method

    def Withdrawal(self, w):
        if (self.balance < w):
            print("impossible operation! Insufficient balance !")
        else:
            self.balance = self.balance - w

            # create bankFees() method

    def bankFees(self):
        self.balance = (95 / 100) * self.balance

        # create display() method

    def display(self):
        print("Account Number : ", self.accountNumber)
        print("Account Owner Name : ", self.name)
        print("Account Balance : ", "₹", self.balance)

    # Testing the code :


accno = int(input('Enter your account number:'))
accholder = input("Enter your name:")
amt = int(input('Enter the amount:'))
newAccount = BankAccount(accno, accholder, amt)
# Creating Withdrawal Test
wdraw = int(input('Enter amount to withdraw'))
newAccount.Withdrawal(wdraw)
# Create deposit test
dep = int(input('Enter amount to deposit'))
newAccount.Deposit(dep)
# Display account informations
newAccount.display()