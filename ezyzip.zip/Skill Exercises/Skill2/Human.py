class Human:
    def __init__(self, name, age, phn):
        self.name = name
        self.age = age
        self.phn = phn

    def get_details(self):
        print("name = ", self.name, "\n", "age = ", self.age, "\n", "phn = ", self.phn, "\n")


class Doctor(Human):
    def __init__(self, doc_name, doc_age, doc_phn, doc_expert):
        super().__init__(doc_name, doc_age, doc_phn)
        self.doc_exper=doc_expert

    def suggest_med_patient(self,pa_prob):
        if pa_prob=="headache":
            med= Medicine("saridon","1 day","1 tablet")
            return med
        elif pa_prob == "fever":
            med = Medicine("dolo650", "1 week", "1 tablet")
            return med
        elif pa_prob =="cold":
            med = Medicine("citrizin", "1 week", "1 tablet")
            return med

class Patient(Human):

    def __init__(self, pa_name, pa_age,pa_phn, pa_prob):
        super().__init__(pa_name,pa_age ,pa_phn)
        self.pa_prob = pa_prob
    def pa_details(self):
        print("problem= ",self.pa_prob,"\n","Prescription:")

class Medicine:
    def __init__(self):
        pass
    def __init__(self, med_name, med_period,med_dose):
        self.med_name = med_name
        self.med_period= med_period
        self.med_dose= med_dose