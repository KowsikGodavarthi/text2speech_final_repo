import pytest




def test_factors():
    assert factors_of_n(5) == [1, 5]





@pytest.fixture()
def input_value():
    return 5


def test_factors(input_value):
    assert factors_of_n(input_value) == [1, 5]




@pytest.mark.parametrize("num,output", [(1, [1]), (2, [1, 2]), (3, [1, 3]), (4, [1, 2, 4]), (5, [1, 5])])
def test_factors(num, output):
    assert factors_of_n(num) == output


def factors_of_n(n):
    arr = []
    for i in range(1, n + 1):
        if n % i == 0:
            arr.append(i)
            print(i)
    return arr