import pytest

""""--------------JUST TESTING ______________________"""


def test_fact():
    assert fact_of_n(5) == 120


"""------------- USING FIXTURES_______________________"""


@pytest.fixture()
def input_value():
    return 5


def test_fact(input_value):
    assert fact_of_n(input_value) == 120


""" -------------------------USING PARAMETERIZED_____________"""


@pytest.mark.parametrize("num,output", [(1, 1), (2, 2), (3, 6), (4, 24), (5, 120)])
def test_fact(num, output):
    assert fact_of_n(num) == output


def fact_of_n(n):
    fact = 1
    for i in range(1, n + 1):
        fact *= i
    print(fact)
    return fact