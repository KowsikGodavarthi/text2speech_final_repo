import pytest

""""--------------JUST TESTING ______________________"""

def test_sum():
    assert sum_of_n(5)==15



"""------------- USING FIXTURES_______________________"""


@pytest.fixture()
def input_value():
    return 5

def test_sum(input_value):
    assert sum_of_n(input_value) ==5



""" -------------------------USING PARAMETERIZED_____________"""


@pytest.mark.parametrize("num,output",[(1,1),(2,3),(3,6),(4,10),(5,15)])
def test_sum(num,output):
    assert sum_of_n(num)==output


def sum_of_n(n):
    sum=0
    for i in range(1,n+1):
        sum+=i
    print(sum,"\n")
    return sum