import Human
import pytest

def test_suggetion_1():
    pa=Human.Patient("hero",15,74185296,"headache")
    doc=Human.Doctor("strange",77,963852741,"neuro")
    med= doc.suggest_med_patient("headache")
    assert med.med_name=="saridon"

def test_suggetion_2():
    pa=Human.Patient("hero",15,74185296,"headache")
    doc=Human.Doctor("strange",77,963852741,"neuro")
    med= doc.suggest_med_patient("headache")
    assert med.med_name=="dolo650"


def test_suggetion_3():
    pa=Human.Patient("hero",15,74185296,"headache")
    doc=Human.Doctor("strange",77,963852741,"neuro")
    med= doc.suggest_med_patient("cold")
    assert med.med_name=="citrizin"