# import psycopg2
# conn = psycopg2.connect(
#     database='FirstConnection',
#     user='postgres',
#     password='Sunnysree27#',
#     host='127.0.0.1',
#     port='5432'
# )
# cursor = conn.cursor()
#
# # sql='''create table studen(id int primary key, sub1 int,sub2 int, sub3 int)
# # '''
# # cursor.execute(sql)
# # cursor.execute('''Insert into student values(3333,57,85,79),(2222,65,75,14);''')
# # cursor.execute('''Insert into student values(4444,57,45,39),(5555,85,45,94);''')
#
# #updating a record
# # sql = "update student set sub1= sub1+100 where id = 3333"
# # cursor.execute(sql)
#
# #fetching all rows
# print("contents of the student table: ")
# sql2='''select *from student'''
# cursor.execute(sql2)
# print(cursor.fetchall())
#
#
# conn.commit()
# conn.close()


import psycopg2
conn = psycopg2.connect(
    database='Manufac',
    user='postgres',
    password='Sunnysree27#',
    host='127.0.0.1',
    port='5432'
)
cursor = conn.cursor()

# sql='''create table employe(id int primary key, perspecific varchar(30),pername varchar(30), manufacture date,MRP int)
# '''
# cursor.execute(sql)
# cursor.execute('''Insert into employe values(708,'1GB','HP','12-09-2022',1500),(513,'2GB','Dell','1-07-2021',1400);''')
# cursor.execute('''Insert into employe values(98,'3GB','Acer','3-09-2021',1000),(14,'4Gb','lenovo','8-09-2023',500);''')

#update
# sql = "update employe set MRP= MRP+1000 where id = 708"
# cursor.execute(sql)
# sql = "update employe set MRP= MRP+1000 where id = 513"
# cursor.execute(sql)


#fetching
print("contents of the Employee table: ")
sql2='''select *from employe'''
cursor.execute(sql2)
print(cursor.fetchall())

#deleting
cursor.execute('''DELETE FROM employe WHERE id >= 708''')

conn.commit()
conn.close()