import csv
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
# Email account details
EMAIL_ADDRESS = '2100030708cse@gmail.com'
EMAIL_PASSWORD = 'ibnjiwigqjhxdwhf'
# Set up SMTP server
smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
smtp_server.starttls()
smtp_server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
with open('email.csv') as file:
    reader = csv.reader(file)
    next(reader)
    for row in reader:
        name, email = row[:2]
        message_obj = MIMEMultipart()
        message_obj['From'] = EMAIL_ADDRESS
        message_obj['To'] = email
        message_obj['Subject'] = 'Bulk Email'

        message_obj.attach(MIMEText('register to samyak', 'plain'))
        smtp_server.sendmail(EMAIL_ADDRESS, email, message_obj.as_string())
        print(f"Email sent to {name} ({email})")

smtp_server.quit()
print("All emails sent successfully.")