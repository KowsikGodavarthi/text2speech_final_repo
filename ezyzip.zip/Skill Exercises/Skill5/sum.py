import csv

# import Mail as Mail
from flask import *
from flask_mail import Mail, Message

app= Flask(__name__)
mail= Mail(app)

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT']=465
app.config['MAIL_USERNAME']='2100030708cse@gmail.com'
app.config['MAIL_PASSWORD']='ibnjiwigqjhxdwhf'
app.config['MAIL_USE_TLS']=False
app.config['MAIL_USE_SSL']=True

mail=Mail(app)


@app.route('/')
def index():
    return render_template('sendmails.html')


@app.route('/send', methods=['POST'])
def send():
    with open('employees.csv', mode='r') as file:
        csvfile=csv.reader(file)
        for ids,emails in csvfile:
            msg = Message(f' New Block Opening', sender='2100030708cse@gmail', recipients=[emails])
            msg.body = '''
                            Dear Employees,
                            I hope this message finds you well. I am writing to invite you all for the opening of our new block on 20th Jan 2022.
                             Hope I will meet you all there. Thank you.'''
            mail.send(msg)
            print(f'sent to {ids}')
    return "<h1>Sending mails completed</h1>"


if __name__=="__main__":
    app.run(debug=True)

